brew install --no-quarantine --cask wine stable
echo ok
